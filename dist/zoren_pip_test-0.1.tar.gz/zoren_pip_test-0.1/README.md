Prueba de empacar una librería en Python con un proyecto de Scumting de Carlos Iker Fuentes Reyes (AKA Nigger)
